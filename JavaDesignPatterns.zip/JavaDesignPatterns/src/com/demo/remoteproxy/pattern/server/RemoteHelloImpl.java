/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.demo.remoteproxy.pattern.server;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author sangeethas
 */
public class RemoteHelloImpl extends UnicastRemoteObject implements RemoteHello {
    public RemoteHelloImpl(String name) throws RemoteException {
        super();
        try {
            Naming.rebind(name, this);
        } catch (MalformedURLException ex) {
            Logger.getLogger(RemoteHelloImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @Override
    public String sayHello(String name) {
        return "Hello, "+name+" Welcome to Remote .....";
    }
}
