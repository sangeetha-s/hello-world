/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.demo.factory.pattern;

/**
 *
 * @author sangeethas
 */
public class Square extends Shape{
    public Square() {
        super(ShapeType.SQUARE);
    }
    
    @Override
    public void shapeInfo() {
        System.out.println("Shape Info..... SQUARE!!!");
    }
}
