/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.demo.factory.pattern;

/**
 *
 * @author sangeethas
 */
public class ShapeFactory {

    private static Shape shape;

    public static Shape getShape(ShapeType shapeType) {
        switch (shapeType) {
            case SQUARE:
                shape = new Square();
                break;
            case TRIANGLE:
                shape = new Triangle();
                break;
            case CIRCLE:
                shape = new Circle();
                break;
        }
        return shape;
    }
}
