/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.demo.factory.pattern;

/**
 *
 * @author sangeethas
 */
public class TestFactory {

    public static void main(String[] args) {
        Shape shape = ShapeFactory.getShape(ShapeType.SQUARE);
        shape.shapeInfo();

        shape = ShapeFactory.getShape(ShapeType.CIRCLE);
        shape.shapeInfo();

        shape = ShapeFactory.getShape(ShapeType.TRIANGLE);
        shape.shapeInfo();

    }
}
