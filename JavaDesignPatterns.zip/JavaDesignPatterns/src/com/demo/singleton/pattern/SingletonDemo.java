/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.demo.singleton.pattern;

/**
 *
 * @author sangeethas
 */
public class SingletonDemo {

    private SingletonDemo() {

    }

    private static class SingletonHolder {
        private static SingletonDemo instance = new SingletonDemo();
    }

    public static SingletonDemo getInstance() {
        return SingletonHolder.instance;
    }
}
