/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.demo.singleton.pattern;

/**
 *
 * @author sangeethas
 */
public class TestSingleton {
    public static void main(String[] args) {
        Singleton singleton = Singleton.getInstance();
        System.out.println("1: "+singleton);
        
        singleton = Singleton.getInstance();
        System.out.println("2: "+singleton);
        
        singleton = Singleton.getInstance();
        System.out.println("3: "+singleton);
    }
}
