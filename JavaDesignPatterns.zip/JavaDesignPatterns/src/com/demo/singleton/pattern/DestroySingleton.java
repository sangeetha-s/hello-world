/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.demo.singleton.pattern;

import java.lang.reflect.Constructor;

/**
 *
 * @author sangeethas
 */
public class DestroySingleton {

    public static void main(String[] args) {
        Singleton singleton = Singleton.getInstance();
        System.out.println("Singleton Object(before): " + singleton);

        try {
            Constructor[] cons = Singleton.class.getDeclaredConstructors();         
            for (Constructor con : cons) {
                con.setAccessible(true);   
                singleton = (Singleton)con.newInstance();
                System.out.println("Singleton Object(after.): "+singleton);
            }

        } catch (Exception err) {
              System.out.println(err.getMessage());
        }
    }
}
