/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.demo.singleton.pattern;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author sangeethas
 */
public class SingletonSerialization {
    public static void main(String[] args) {
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream("singletonobject.ser");
            Singleton single = Singleton.getInstance();
            System.out.println("Singleton Object: "+single);
            try (ObjectOutputStream oos = new ObjectOutputStream(fos)) {
                oos.writeObject(single);
            }
            
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream("singletonobject.ser"));
            Singleton s = (Singleton)ois.readObject();
            System.out.println("Singleton Object read from file: "+s);
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(SingletonSerialization.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(SingletonSerialization.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(SingletonSerialization.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                fos.close();
            } catch (IOException ex) {
                Logger.getLogger(SingletonSerialization.class.getName()).log(Level.SEVERE, null, ex);
            }
        }        
        
    }
}
