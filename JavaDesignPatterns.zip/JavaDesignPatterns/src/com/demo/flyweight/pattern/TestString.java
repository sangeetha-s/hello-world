/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.demo.flyweight.pattern;

/**
 *
 * @author sangeethas
 */
public class TestString {
    public static void main(String[] args) {
        String s = "Infosys";
        String s1 = "Infosys";
        System.out.println("s1 and s2 Equal: "+(s == s1));        
        
        String s3 = new String("Infosys");
        String s4 = new String("Infosys");
        System.out.println("s3 and s4 Equal: "+(s3 == s4));
        
        s3=s3.intern();
        System.out.println("s1 and s3 Equal: "+(s1 == s3));
    }
}
