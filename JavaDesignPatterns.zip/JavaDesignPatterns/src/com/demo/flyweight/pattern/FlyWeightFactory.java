/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.demo.flyweight.pattern;

import java.util.EnumMap;
import java.util.Map;

/**
 *
 * @author sangeethas
 */
public class FlyWeightFactory {

    private static FlyWeightFactory instance;
    private static Map<ShapeType, Shape> instancePool;
    private Shape shape;

    private FlyWeightFactory() {
        instancePool = new EnumMap<>(ShapeType.class);
    }

    public static FlyWeightFactory getInstance() {
        if (instance == null) {
            instance = new FlyWeightFactory();
        }
        return instance;
    }

    public Shape getShape(ShapeType shapeType) {
        if(instancePool.containsKey(shapeType)) {
            System.out.println("Use Exising....");
            return instancePool.get(shapeType);
        }
        switch (shapeType) {
            case SQUARE:
                shape = new Square();
                System.out.println("New one.....");
                break;
            case CIRCLE:
                shape = new Circle();
                System.out.println("New one.....");
                break;
            case TRIANGLE:
                shape = new Triangle();
                System.out.println("New one.....");
                break;
        }
        instancePool.put(shapeType, shape);
        return shape;
    }

}
