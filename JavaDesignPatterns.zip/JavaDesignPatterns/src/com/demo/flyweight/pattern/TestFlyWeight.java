/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.demo.flyweight.pattern;

/**
 *
 * @author sangeethas
 */
public class TestFlyWeight {

    public static void main(String[] args) {
        FlyWeightFactory factory = FlyWeightFactory.getInstance();
        Shape shape;
        for (int index = 0; index < 2; index++) {
            shape = factory.getShape(ShapeType.SQUARE);
            shape.shapeInfo();

            shape = factory.getShape(ShapeType.CIRCLE);
            shape.shapeInfo();

            shape = factory.getShape(ShapeType.TRIANGLE);
            shape.shapeInfo();
        }
    }
}
