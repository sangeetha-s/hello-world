package com.patterns.creational.singleton;

public enum EnumSingleton {
	 INSTANCE;
}
