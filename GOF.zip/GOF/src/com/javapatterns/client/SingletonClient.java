package com.javapatterns.client;

import com.patterns.creational.singleton.Singleton;

public class SingletonClient {

	public static void main(String[] args) {
		Singleton instanceOne = Singleton.getInstance();
		Singleton instanceTwo = Singleton.getInstance();

		System.out.println("instanceOne hasCode:" + instanceOne);
		System.out.println("instanceTwo hasCode:" + instanceTwo);

	}

}
