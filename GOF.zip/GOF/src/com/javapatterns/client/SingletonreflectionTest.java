package com.javapatterns.client;

import java.lang.reflect.Constructor;

import com.patterns.creational.singleton.*;

public class SingletonreflectionTest {

	public static void main(String[] args) {
		        SingletonInnerStatic instanceOne = SingletonInnerStatic.getInstance();
		        SingletonInnerStatic instanceTwo = null;
		        try {
		            Constructor[] constructors = SingletonInnerStatic.class.getDeclaredConstructors();
		            for (Constructor constructor : constructors) {
		                //Below code will destroy the singleton pattern
		                constructor.setAccessible(true);
		                instanceTwo = (SingletonInnerStatic) constructor.newInstance();
		                break;
		            }
		        } catch (Exception e) {
		            e.printStackTrace();
		        }
		        System.out.println(instanceOne.hashCode());
		        System.out.println(instanceTwo.hashCode());
		    }
}
